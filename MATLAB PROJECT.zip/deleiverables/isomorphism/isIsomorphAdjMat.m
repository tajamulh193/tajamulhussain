function result = isIsomorphAdjMat(A, B)
    if size(A, 1) ~= size(B, 1)
        result = false;
        return;
    end
    
    n = size(A, 1);
    visited = false(1, n);
    permutation = zeros(1, n);
    result = backtrack(1);
    
    function res = backtrack(index)
        if index > n
            res = isequal(A(permutation, permutation), B);
            return;
        end
        
        res = false;
        for i = 1:n
            if ~visited(i)
                visited(i) = true;
                permutation(index) = i;
                res = res || backtrack(index + 1);
                visited(i) = false;
            end
        end
    end
end
