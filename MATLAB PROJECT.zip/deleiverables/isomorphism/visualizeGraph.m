function visualizeGraph(A)
    % Create a 2D plot of the graph
    n = size(A, 1);
    angles = linspace(0, 2*pi, n+1);
    angles(end) = [];
    x = cos(angles);
    y = sin(angles);

    figure;
    hold on;
    for i = 1:n
        for j = i+1:n
            if A(i, j) == 1
                plot([x(i), x(j)], [y(i), y(j)], '-b');
            end
        end
    end
    plot(x, y, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    axis equal;
    hold off;
end