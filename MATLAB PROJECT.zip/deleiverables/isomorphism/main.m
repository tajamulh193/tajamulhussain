graph1_inc = [1 0 1; 1 1 0; 0 1 1];
graph2_inc = [1 1 0; 0 1 1; 1 0 1];


% Task B:
disp("Task B: Brute Force Approach with Adjacency Matrices");
result_b = isIsomorphAdjMat(graph1_inc, graph2_inc);
disp("Graphs are isomorphic: " + result_b);

% Task C:
disp("Task C: Brute Force Approach with Incidence Matrices");
result_c = isIsomorphIncMat(graph1_inc, graph2_inc);
disp("Graphs are isomorphic: " + result_c);

% Task D:
disp("Task D: Weisfeiler-Lehman Algorithm with Adjacency Matrices");
result_d = isIsomorphWeisfeilerLehman(graph1_inc, graph2_inc);
disp("Graphs are isomorphic: " + result_d);


% Visualization of the graphs
gdj1 = graph1_inc' * graph1_inc;
gdj2 = graph2_inc' * graph2_inc;

% Create directed graphs using adjacency matrices
G1 = digraph(gdj1);
G2 = digraph(gdj2);

% Plot the graphs
subplot(1, 2, 1);
plot(G1);
title('Graph 1');

subplot(1, 2, 2);
plot(G2);
title('Graph 2');
