function result = isIsomorphIncMat(A, B)
    if ~isequal(sum(A, 2), sum(B, 2))
        result = false;
        return;
    end

    n = size(A, 1);
    visited = false(1, n);
    permutation = zeros(1, n);
    result = backtrack(1);
    
    function res = backtrack(index)
        if index > n
            res = isequal(A(permutation, :), B);
            return;
        end
        
        res = false;
        for i = 1:n
            if ~visited(i)
                visited(i) = true;
                permutation(index) = i;
                res = res || backtrack(index + 1);
                visited(i) = false;
            end
        end
    end
end
