function result = isIsomorphWeisfeilerLehman(graph1, graph2)
    if size(graph1, 1) ~= size(graph2, 1)
        result = false;
        return;
    end

    refined_graph1 = weisfeilerLehmanRefine(graph1);
    refined_graph2 = weisfeilerLehmanRefine(graph2);
    result = isequal(refined_graph1, refined_graph2);
end

