function refined_graph = weisfeilerLehmanRefine(graph)
    num_vertices = size(graph, 1);
    vertex_labels = cell(num_vertices, 1);

    for i = 1:num_vertices
        vertex_labels{i} = num2str(sum(graph(i, :)));
    end

    max_iterations = 5;
    for iteration = 1:max_iterations
        new_labels = cell(num_vertices, 1);
        for i = 1:num_vertices
            neighbors = find(graph(i, :));
            neighbor_labels = sort(vertex_labels(neighbors));
            new_labels{i} = [vertex_labels{i}, strjoin(neighbor_labels)];
        end
        vertex_labels = new_labels;
    end

    % The refined_graph is the same as vertex_labels
    refined_graph = vertex_labels;
end