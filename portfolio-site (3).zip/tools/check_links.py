#!/usr/bin/env python3
"""Check every local link, image, stylesheet and script in the site's HTML files.

Run from the repository root:  python tools/check_links.py

For each .html file it checks that:
  - every relative href/src points to a file that exists (case-sensitive, like GitHub Pages),
  - every #fragment points to an id that exists in the target page,
  - no link starts with "/" (such links break when the site lives in a sub-folder),
  - no link points at localhost.
External https links are only checked for format, not fetched.
Exits with status 1 if anything is wrong.
"""
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import unquote, urldefrag, urlparse

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {".git", ".github", "node_modules"}
# These HTML files are part of other projects (served by their own server) and use /api paths.
SKIP_FILES = {os.path.join("projects", "project-tracker-api", "public", "index.html")}


class Collector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.ids = [], set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get("id"):
            self.ids.add(a["id"])
        if tag == "a" and a.get("name"):
            self.ids.add(a["name"])
        for key in ("href", "src"):
            if a.get(key) is not None and not (tag == "link" and a.get("rel") in ("preconnect", "dns-prefetch")):
                self.refs.append((tag, key, a[key]))


def parse(path):
    c = Collector()
    with open(path, encoding="utf-8") as fh:
        c.feed(fh.read())
    return c


def exists_case_sensitive(path):
    """True only if every path segment matches exactly, as on Linux."""
    rel = os.path.relpath(path, ROOT)
    cur = ROOT
    for part in rel.split(os.sep):
        if part == ".":
            continue
        if part not in os.listdir(cur):
            return False
        cur = os.path.join(cur, part)
    return True


def main():
    pages = []
    for d, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        for f in files:
            full = os.path.join(d, f)
            if f.endswith(".html") and os.path.relpath(full, ROOT) not in SKIP_FILES:
                pages.append(full)

    cache, problems, checked = {}, [], 0
    for page in sorted(pages):
        rel_page = os.path.relpath(page, ROOT)
        cache[page] = parse(page)
    for page in sorted(pages):
        rel_page = os.path.relpath(page, ROOT)
        for tag, key, value in cache[page].refs:
            checked += 1
            v = value.strip()
            if not v or v.startswith(("mailto:", "tel:", "javascript:", "data:")):
                continue
            if "localhost" in v:
                problems.append(f"{rel_page}: {key}={v} points at localhost")
                continue
            parsed = urlparse(v)
            if parsed.scheme in ("http", "https"):
                if not parsed.netloc:
                    problems.append(f"{rel_page}: malformed URL {v}")
                continue
            if v.startswith("//"):
                continue
            if v.startswith("/"):
                problems.append(f"{rel_page}: {key}={v} starts with '/', use a relative path")
                continue
            target, frag = urldefrag(v)
            target_path = page if not target else os.path.normpath(os.path.join(os.path.dirname(page), unquote(target.split("?")[0])))
            if os.path.isdir(target_path):
                target_path = os.path.join(target_path, "index.html")
            if not os.path.isfile(target_path) or not exists_case_sensitive(target_path):
                problems.append(f"{rel_page}: {key}={v} does not exist")
                continue
            if frag and target_path.endswith(".html"):
                if target_path not in cache:
                    cache[target_path] = parse(target_path)
                if frag not in cache[target_path].ids:
                    problems.append(f"{rel_page}: {key}={v} has no element with id '{frag}'")

    print(f"Checked {len(pages)} pages and {checked} references.")
    if problems:
        print(f"{len(problems)} problem(s):")
        for p in problems:
            print("  -", p)
        return 1
    print("All links and assets are valid.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
