function image_feats = get_tiny_images(image_paths)
    % Input: image_paths - N x 1 cell array of image file paths
    % Output: image_feats - N x d matrix of resized and vectorized tiny images
    
    tiny_image_size = [16, 16];
    num_images = numel(image_paths);
    image_feats = zeros(num_images, prod(tiny_image_size));
    for i = 1:num_images
        try
            img = imread(image_paths{i});
            
            resized_img = imresize(img, tiny_image_size, 'bilinear');
            
            gray_img = rgb2gray(resized_img);
            
            image_feats(i, :) = gray_img(:)';
        catch
            fprintf('Error reading image: %s\n', image_paths{i});
        end
    end
end