function image_feats = get_colour_histograms(image_paths)
    % Input: image_paths - N x 1 cell array of image file paths
    % Output: image_feats - N x d matrix of color histogram features
    
    num_bins = 16;
    num_images = numel(image_paths);
    image_feats = zeros(num_images, 3 * num_bins);
   
    for i = 1:num_images
        try
            img = imread(image_paths{i});
            
            hsv_img = rgb2hsv(img);
            
            h_channel = hsv_img(:, :, 1);
            s_channel = hsv_img(:, :, 2);
            v_channel = hsv_img(:, :, 3);
            
            h_hist = histcounts(h_channel, num_bins) / numel(h_channel);
            s_hist = histcounts(s_channel, num_bins) / numel(s_channel);
            v_hist = histcounts(v_channel, num_bins) / numel(v_channel);
            
            image_feats(i, :) = [h_hist, s_hist, v_hist];
        catch
            fprintf('Error reading image: %s\n', image_paths{i});
        end
    end
end
