function predicted_categories = nearest_neighbor_classify(train_image_feats, train_labels, test_image_feats)
    % using the nearest neighbor classifier with cosine distance.
    % Input: train_image_feats - N x d matrix of training image features
    %        train_labels - N x 1 cell array of training image labels
    %        test_image_feats - M x d matrix of test image features
    % Output: predicted_categories - M x 1 cell array of predicted categories for test images

    num_train = size(train_image_feats, 1);
    num_test = size(test_image_feats, 1);

    predicted_categories = cell(num_test, 1);

    for i = 1:num_test
        dot_product = sum(train_image_feats .* test_image_feats(i, :), 2);
        norm_train = sqrt(sum(train_image_feats.^2, 2));
        norm_test = sqrt(sum(test_image_feats(i, :).^2));
        distances = 1 - dot_product ./ (norm_train .* norm_test);
        [~, nearest_idx] = min(distances);
        predicted_categories{i} = train_labels{nearest_idx};
    end
end