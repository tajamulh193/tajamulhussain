function isAuthenticated(req, res, next) {
  const isLoggedIn = req.session.isLoggedIn || false;

  if (isLoggedIn) {
    next();
  } else {
    res.redirect('/login');
  }
}

module.exports = isAuthenticated;
