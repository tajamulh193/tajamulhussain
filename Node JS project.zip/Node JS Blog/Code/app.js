const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');
const session = require('express-session');
const csrf = require('csurf');
require('./db');

const app = express();
const port = process.env.PORT || 3000;
const csrfProtection = csrf({cookie: true});

// Middlewares
app.use(express.static(path.join(__dirname, 'frontend')));
app.use('/images', express.static(path.join(__dirname, 'images')));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(session({ secret: '58841515156', resave: false, 
saveUninitialized: true, cookie: {secure: false}}));
app.use(csrfProtection);

// Route Handlers
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');

app.use(authRoutes);
app.use(postRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
