const {Pool} = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'blog',
  password: '1234',
  port: 5432,
});

const secretKey = '58841515156';

module.exports = {pool, secretKey};
