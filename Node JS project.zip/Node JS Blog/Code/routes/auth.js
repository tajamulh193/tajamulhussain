const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const router = express.Router();
const {pool, secretKey} = require('../db');

router.post('/api/register', async (req, res) => {
  const {username, password} = req.body;

  try {
    const userExists = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (userExists.rows.length > 0) {
      return res.status(400).json({message: 'Registration failed. Username already taken'});
    }

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    await pool.query('INSERT INTO users (username, password) VALUES ($1, $2)', [username, hashedPassword]);
    res.status(201).json({message: 'User registered successfully'});
  } catch (err) {
    console.error('Error while registering user:', err);
    res.status(500).json({message: 'An error occurred during user registration'});
  }
});

router.post('/api/login', async (req, res) => {
  const {username, password} = req.body;

  const user = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
  if (user.rows.length === 0) {
    return res.status(401).json({message: 'Invalid username or password'});
  }

  const isPasswordMatch = await bcrypt.compare(password, user.rows[0].password);
  if (!isPasswordMatch) {
    return res.status(401).json({message: 'Invalid username or password'});
  }


  req.session.isLoggedIn = true;
  req.session.userId = user.rows[0].id;

  const token = jwt.sign({id: user.rows[0].id, username: user.rows[0].username}, secretKey);
  res.cookie('csrfToken', req.csrfToken());
  res.json({token});
});

router.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error while destroying session:', err);
      return res.status(500).json({message: 'Error during logout'});
    }
    res.clearCookie('connect.sid');
    res.json({message: 'Logged out successfully'});
  });
});

module.exports = router;
