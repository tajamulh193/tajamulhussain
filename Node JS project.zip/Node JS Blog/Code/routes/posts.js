const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const isAuthenticated = require('../middleware/isAuthenticated');
const {pool} = require('../db');

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, 'images');
  },
  filename: function(req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  },
});

const frontendPath = path.join(__dirname, '..', '..', 'code/frontend');
const upload = multer({storage: storage});


router.get('/api/all-posts', async (req, res) => {
  try {
    const posts = await pool.query(`
      SELECT posts.*, (SELECT username FROM users WHERE id = posts.user_id) as username
      FROM posts
      ORDER BY posts.id ASC
    `);

    res.status(200).json(posts.rows);
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    res.status(500).json({message: 'An error occurred while fetching blog posts'});
  }
});


router.get('/api/posts', isAuthenticated, async (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.status(403).json({message: 'Access denied'});
  }

  const user_id = req.session.userId;
  try {
    const posts = await pool.query('SELECT * FROM posts WHERE user_id = $1 ORDER BY id ASC', [user_id]);

    res.status(200).json(posts.rows);
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    res.status(500).json({message: 'An error occurred while fetching blog posts'});
  }
});

router.post('/api/posts', isAuthenticated, upload.single('image'), async (req, res) => {
  const {title, content} = req.body;
  const user_id = req.session.userId;

  try {
    const imageFilePath = req.file.path;
    await pool.query('INSERT INTO posts (user_id, title, content, image) VALUES ($1, $2, $3, $4)', [
      user_id,
      title,
      content,
      imageFilePath,
    ]);
    res.status(201).json({message: 'Blog post created successfully'});
  } catch (error) {
    console.error('Error creating blog post:', error);
    res.status(500).json({message: 'An error occurred while creating the blog post'});
  }
});

router.put('/api/posts/:id', isAuthenticated, async (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.status(403).json({message: 'Access denied'});
  }


  const {title, content} = req.body;
  const postId = req.params.id;
  const user_id = req.session.userId;

  try {
    const post = await pool.query('SELECT * FROM posts WHERE id = $1 AND user_id = $2', [postId, user_id]);

    if (post.rows.length === 0) {
      return res.status(404).json({message: 'Blog post not found or you do not have permission to update it'});
    }

    await pool.query('UPDATE posts SET title = $1, content = $2 WHERE id = $3', [title, content, postId]);
    res.json({message: 'Blog post updated successfully'});
  } catch (error) {
    console.error('Error updating blog post:', error);
    res.status(500).json({message: 'An error occurred while updating the blog post'});
  }
});

router.delete('/api/posts/:id', isAuthenticated, async (req, res) => {
  if (!req.session.isLoggedIn) {
    return res.status(403).json({message: 'Access denied'});
  }

  const postId = req.params.id;
  const user_id = req.session.userId;

  try {
    const post = await pool.query('SELECT * FROM posts WHERE id = $1 AND user_id = $2', [postId, user_id]);

    if (post.rows.length === 0) {
      return res.status(404).json({message: 'Blog post not found or you do not have permission to delete it'});
    }


    const imageFilePath = post.rows[0].image;


    if (imageFilePath) {
      fs.unlinkSync(imageFilePath);
    }

    await pool.query('DELETE FROM posts WHERE id = $1', [postId]);
    res.json({message: 'Blog post deleted successfully'});
  } catch (error) {
    console.error('Error deleting blog post:', error);
    res.status(500).json({message: 'An error occurred while deleting the blog post'});
  }
});

router.get('/api/posts/:id', async (req, res) => {
  const postId = req.params.id;
  try {
    const post = await pool.query('SELECT * FROM posts WHERE id = $1', [postId]);
    if (post.rows.length === 0) {
      return res.status(404).json({message: 'Blog post not found'});
    }
    res.status(200).json(post.rows[0]);
  } catch (error) {
    console.error('Error fetching blog post:', error);
    res.status(500).json({message: 'An error occurred while fetching the blog post'});
  }
});

router.get('/api/csrf-token', (req, res) => {
  res.json({csrfToken: req.csrfToken()});
});

router.get('/signup', (req, res) => {
  res.sendFile(path.join(frontendPath, 'signup.html'));
});

router.get('/login', (req, res) => {
  res.sendFile(path.join(frontendPath, 'login.html'));
});
router.get('/blog', (req, res) => {
  res.sendFile(path.join(frontendPath, 'blog.html'));
});
router.get('/', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

router.get('', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});
router.get('/editblog?:id', (req, res) => {
  res.sendFile(path.join(frontendPath, 'editblog.html'));
});
module.exports = router;
