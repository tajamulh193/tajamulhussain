1) First of all, open the code in the code editor like Visual Studio code.
2) open terminal, Check node and npm version by using the below commands:
			npm --version
			node --version

3) After doing that, you are ensured that you have all the necessary thing setted up for the execution of this node project.
4) Then right inside the terminal run command `npm install` This will install the required packages required to run this.
5) After all the packages has been installed. you must ensure you have postgresSQL setted up on your pc. To check, type command:
			psql -U postgres
6) It will set-up the postgres. 

7) create a database called blog by using the command `createdb blog`. Then, run the below queries:

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    image character varying(255)
);

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL
);



7) When all of that been setupped properly, run commnad `npm start` it will start the localhost on port 3000.
8) Open Chrome and type `localhost:3000/` and you can see your required application.