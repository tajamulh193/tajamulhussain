async function fetchBlogPosts() {
  try {
    const response = await fetch('/api/all-posts');
    if (!response.ok) {
      throw new Error('Error fetching blog posts.');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    return [];
  }
}

function createBlogCard(post) {
  // Truncate the content to show only the first 100 characters
  const truncatedContent = post.content.length > 100 ? post.content.substring(0, 100) + '...' : post.content;

  return `
      <div class='card card-post text-light'>
        <img src="${post.image}" class='d-none d-md-block blog-card-img card-img-top'/>
        <div class='card-body blog-card-body d-sm-12 '>
          <h3 class='card-title' style='font-weight: bold;'>${post.title}</h3>
          <p class='card-title d-none d-lg-block' style="font-size:20px; color:rgb(193, 193, 193)">${truncatedContent}</p>
          <p class="card-text" style="color:rgb(193, 193, 193)">Posted by <b>${post.username}</b></p>
          <p class="card-text" style="color:rgb(193, 193, 193);">Posted at ${post.created_at}</p>
          <a href='blogdetail.html?id=${post.id}'><button style='width:100px' type='button' name='read' class='btn btn-primary mt-3 ml-0'><b>Read More </b></button></a>
        </div>
      </div>
    `;
}

async function displayBlogPosts() {
  const blogPostsContainer = document.getElementById('blogPostsContainer');
  blogPostsContainer.innerHTML = '<p>Loading blog posts...</p>';

  const blogPosts = await fetchBlogPosts();

  if (blogPosts.length === 0) {
    blogPostsContainer.innerHTML = '<p>No blog posts available.</p>';
  } else {
    blogPostsContainer.innerHTML = blogPosts.map(createBlogCard).join('');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  displayBlogPosts();

  const readMoreButtons = document.querySelectorAll('button[name="read"]');
  readMoreButtons.forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      const postId = button.dataset.postId;
      window.location.href = `blogdetail.html?id=${postId}`;
    });
  });
});
