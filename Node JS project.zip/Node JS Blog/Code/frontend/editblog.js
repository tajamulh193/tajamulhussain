const editPostForm = document.getElementById('editPostForm');

function getPostIdFromURL() {
  const urlParams = new URLSearchParams(window.location.search);
  console.log(urlParams.get('id'));
  return urlParams.get('id');
}

async function fetchBlogPost(postId) {
  try {
    const response = await fetch(`/api/posts/${postId}`);
    if (!response.ok) {
      throw new Error('Error fetching blog post.');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching blog post:', error);
    return null;
  }
}

async function updateBlogPost(postId, title, content, csrfToken) {
  const response = await fetch(`/api/posts/${postId}`, {
    method: 'PUT',
    headers: {
      'CSRF-Token': csrfToken,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({title, content}),
  });

  print(response);
  if (response.ok) {
    alert('Blog post updated successfully!');
    window.location.replace('/blog');
  } else {
    const errorMessage = await response.json();
    alert(errorMessage.message);
  }
}

editPostForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const postId = getPostIdFromURL();

  const title = document.getElementById('editPostTitle').value;
  const content = document.getElementById('editPostContent').value;

  try {
    const csrfToken = getCSRFToken();

    await updateBlogPost(postId, title, content, csrfToken);
  } catch (error) {
    console.error('Error:', error);
    alert('An error occurred while updating the blog post.');
  }
});

function getCSRFToken() {
  return document.cookie
      .split('; ')
      .find((row) => row.startsWith('csrfToken='))
      .split('=')[1];
}

document.addEventListener('DOMContentLoaded', async () => {
  const postId = getPostIdFromURL();

  if (postId) {
    const blogPost = await fetchBlogPost(postId);

    if (blogPost) {
      document.getElementById('editPostTitle').value = blogPost.title;
      document.getElementById('editPostContent').value = blogPost.content;
    }
  }
});
