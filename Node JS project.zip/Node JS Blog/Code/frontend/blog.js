/**
 * Fetches blog posts from the server and displays them on the page.
 */
async function getBlogPosts() {
  try {
    const csrfToken = getCSRFToken();

    const response = await fetch('/api/posts', {
      headers: {
        'CSRF-Token': csrfToken,
      },
    });

    if (!response.ok) {
      throw new Error('Error fetching blog posts.');
    }

    const posts = await response.json();
    blogPostsElement.innerHTML = '';

    if (posts.length === 0) {
      blogPostsElement.innerHTML = '<p>No blog posts available.</p>';
    } else {
      posts.forEach((post) => {
        const postElement = document.createElement('div');
        postElement.classList.add('blog-post');
        postElement.dataset.id = post.id;
        console.log('Post Image URL:', post.image);
        const truncatedContent = post.content.length > 100 ? post.content.substring(0, 100) + '...' : post.content;
        postElement.innerHTML = `
  <div class="card mb-3">
    ${post.image ? `<img src="${post.image}" alt="Blog Image" class="card-img-top" style="height: 300px; object-fit: cover;">` : ''}
    <div class="card-body">
      <h2 class="card-title">${post.title}</h2>
      <p class="card-text">${truncatedContent}</p>
      <div class="d-flex justify-content-between">
        <button class="btn btn-primary edit-button">Edit</button>
        <button class="btn btn-danger delete-button">Delete</button>
      </div>
    </div>
  </div>
`;

        blogPostsElement.appendChild(postElement);
      });
    }
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    blogPostsElement.innerHTML = '<p>You have no blog posts.</p>';
  }
}

/**
 * Updates a blog post on the server.
 * @param {number} postId - The ID of the post to update.
 * @param {string} title - The updated title of the post.
 * @param {string} content - The updated content of the post.
 */
async function updatePost(postId, title, content) {
  const token = localStorage.getItem('token');
  const csrfToken = getCSRFToken();
  const response = await fetch(`/api/posts/${postId}`, {
    method: 'PUT',
    headers: {
      'CSRF-Token': csrfToken,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ title, content }),
  });

  if (response.ok) {
    getBlogPosts();
    editPostId = null;

    document.getElementById('postTitle').value = '';
    document.getElementById('postContent').value = '';
  } else {
    const errorMessage = await response.json();
    alert(errorMessage.message);
  }
}

/**
 * Deletes a blog post from the server.
 * @param {number} postId - The ID of the post to delete.
 */
async function deletePost(postId) {
  const token = localStorage.getItem('token');
  const csrfToken = getCSRFToken();

  const response = await fetch(`/api/posts/${postId}`, {
    method: 'DELETE',
    headers: {
      'CSRF-Token': csrfToken,
    },
  });

  if (response.ok) {
    getBlogPosts();
  } else {
    const errorMessage = await response.json();
    alert(errorMessage.message);
  }
}

/**
 * Retrieves the CSRF token from the cookies.
 * @returns {string} The CSRF token.
 */
function getCSRFToken() {
  return document.cookie
    .split('; ')
    .find((row) => row.startsWith('csrfToken='))
    .split('=')[1];
}

// DOM Elements
const blogPostsElement = document.getElementById('blogPosts');
const newPostForm = document.getElementById('newPostForm');
let editPostId = null;

// Event listeners
newPostForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const title = document.getElementById('postTitle').value;
  const content = document.getElementById('postContent').value;
  const imageFile = document.getElementById('postImage').files[0];

  try {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('content', content);
    formData.append('image', imageFile);

    const csrfToken = getCSRFToken();

    if (editPostId) {
      await updatePost(editPostId, formData, csrfToken);
    } else {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'CSRF-Token': csrfToken,
        },
        body: formData,
      });

      if (response.ok) {
        getBlogPosts();
        newPostForm.reset();
      } else {
        alert('Error creating blog post');
      }
    }
  } catch (error) {
    console.error('Error:', error);
    alert('An error occurred while creating the blog post.');
  }
});

blogPostsElement.addEventListener('click', (e) => {
  if (e.target.classList.contains('edit-button')) {
    const postElement = e.target.closest('.blog-post');
    const postId = postElement.dataset.id;
    openEditBlogPage(postId);
  } else if (e.target.classList.contains('delete-button')) {
    const postElement = e.target.closest('.blog-post');
    const postId = postElement.dataset.id;
    deletePost(postId);
  }
});

document.getElementById('logoutButton').addEventListener('click', async () => {
  try {
    const csrfToken = getCSRFToken();

    const response = await fetch('/api/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'CSRF-Token': csrfToken,
      },
    });
    if (response.ok) {
      window.location.replace('/login.html');
    } else {
      const data = await response.json();

      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: data.error,
      });
    }
  } catch (error) {
    console.error('Error during logout:', error);
    alert('An error occurred during logout.');
  }
});

// Automatically fetch blog posts on page load.
getBlogPosts();