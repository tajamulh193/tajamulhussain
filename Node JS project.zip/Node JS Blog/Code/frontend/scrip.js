async function signUp(username, password, csrfToken) {
  console.log('Username:', username);
  console.log('Password:', password);

  const response = await fetch('/api/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'CSRF-Token': csrfToken,
    },
    body: JSON.stringify({username, password}),
  });

  if (response.ok) {
    alert('Sign up successful! You can now login.');
    window.location.href = 'login.html';
  } else {
    const errorMessage = await response.json();
    alert(errorMessage.message);
  }
}


async function getCSRFToken() {
  const response = await fetch('/api/csrf-token');
  const data = await response.json();
  return data.csrfToken;
}

const signUpForm = document.getElementById('signUpForm');
signUpForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  try {
    const csrfToken = await getCSRFToken();
    signUp(username, password, csrfToken);
    signUpForm.reset();
  } catch (error) {
    console.error('Error:', error);
    alert('An error occurred while signing up.');
  }
});
